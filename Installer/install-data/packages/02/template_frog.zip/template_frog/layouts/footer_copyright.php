<br />
<br />
<p>&copy; <?php echo date("Y"); ?> Scriptmatix Ltd. All Rights Reserved. <br />
<span style="font-size:9px">Powered by <a href="http://www.phppennyauction.com?refer=botlinkadminp" target="_blank" title="PHPPA" style="text-decoration:none;">PHP Penny Auction</a>. We do not have any resellers, please <a href="http://www.phppennyauction.com/contact/" target="_blank">report stolen software</a>.</span><br /></p>
<div class="hr"></div>