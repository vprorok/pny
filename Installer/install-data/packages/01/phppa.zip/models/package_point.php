<?php
class PackagePoint extends AppModel{
    var $name = 'PackagePoint';
    var $belongsTo = array('Package');
}
?>
